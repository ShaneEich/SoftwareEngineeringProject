﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoint2 : MonoBehaviour
{ 

    public Waypoint2 next;

   
}
