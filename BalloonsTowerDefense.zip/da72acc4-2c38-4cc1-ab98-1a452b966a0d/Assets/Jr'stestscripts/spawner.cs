﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour
{
    public Transform StartPoint;
        public GameObject original;
        public int count = 3;
        public float radius = 3;
    public float spawnTime = 3f;
    // Start is called before the first frame update
    void Start()
        {

        //InvokeRepeating("Spawn", spawnTime, spawnTime);
        //for (int i = 0; i < count; i++)
        // {
        //  GameObject clone = Instantiate(original, Random.insideUnitSphere * radius, Quaternion.identity);
        //  clone.GetComponent<MeshRenderer>().material.color = Random.ColorHSV();
        //for (int i = 0; i < count; i++)
        
            //Spawn();
        Invoke("Spawn", 3f);
        this.transform.SetPositionAndRotation(StartPoint.position,Quaternion.identity);

                

            //}
        }
    void Spawn()
    {
        //for (int i = 0; i < count; i++)
          //{
              GameObject clone = Instantiate(original, StartPoint.position , Quaternion.identity);
            









        //}
  }
    
}
