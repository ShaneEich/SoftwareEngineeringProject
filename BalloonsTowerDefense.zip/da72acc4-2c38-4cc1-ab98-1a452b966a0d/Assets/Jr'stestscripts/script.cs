﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
public class script : MonoBehaviour
{
	public TextMeshProUGUI textbox;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void quit()
    {
        SceneManager.LoadScene("MainMenu");
    }
    
	public void Speed()
	{
		if (Time.timeScale == 1.0f)
		{
		    Time.timeScale = 2.0f;
            textbox.text = "Normal";
		}
		else
		{
			Time.timeScale = 1.0f;
            textbox.text = "Speed Up";
		}
	}
}
