﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class balloon2 : MonoBehaviour
{

    public Waypoint2 target;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //transform.position = Vector3.MoveTowards(transform.position, target.position, step);
        transform.position = transform.position + Vector3.Normalize(target.transform.position - transform.position) * Time.deltaTime;

        if (Vector3.Distance(target.transform.position, transform.position) <= 0.1f)
        {
            target = target.next;
        }
    }
}
