﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;

public class move : MonoBehaviour
{
   
    public Transform target;
    public Transform[] points;
    public int wavePointIndex;
    
}




class MoveSystem : ComponentSystem
{
    struct Components
    {
       // public Transform transform;   JUSTIN COMMENTED THIS OUT TO STOP THE WARNING

    }

    

    protected override void OnUpdate()
    {
        foreach(var e in GetEntities<Components>())
        {
            //e.transform.Translate(Vector3.right * Time.deltaTime, Space.World);

            //points = new Transform[transform.childCount];
            //for (int i = 0; i < points.Length; i++)
           // {
            //points[i] = transform.GetChild(i);
           //}



        }
    }

}
