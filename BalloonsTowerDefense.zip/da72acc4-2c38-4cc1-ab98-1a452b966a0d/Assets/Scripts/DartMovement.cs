﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DartMovement : MonoBehaviour
{
    
    public TowerController tower;
    public BalloonController bal;
    public Rigidbody2D rbody;
    public Vector2 d;
    public float speed = 100.0f;


    private void Start()
    {
        rbody = GetComponent<Rigidbody2D>();
        transform.up = bal.transform.position - transform.position;
        transform.Rotate(0, 0, 75);

        //d = bal.transform.position - transform.position;
    }

    private void Update()
    {
        if(bal == null)
        {
            Destroy(this.gameObject);
        }
        else
        {
            d = bal.transform.position - transform.position;
            rbody.velocity = d * 11;
        }
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Balloon")
        {
            other.GetComponent<BalloonController>().damageBalloon(tower.attackDamage, false);
            Destroy(this.gameObject);
        }
    }
}
