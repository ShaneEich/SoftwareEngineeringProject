﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using TMPro;

public class BalloonController : MonoBehaviour {

    public float speed = 10f;
    private float lastspeed;

    private Transform target;
    private int wayPointIndex = 0;
    public int damage = 0;
    public int hp;
    private GameObject balloon;
    public bool frozen = false;

    void Start()
    {  
        target = Waypoint.points[0];
        balloon = GameObject.FindWithTag("Balloon");
    }

    void Update()
    {
        Vector3 dir = target.position - transform.position;
        transform.Translate(dir.normalized * speed * Time.deltaTime, Space.World);

        if (Vector3.Distance(transform.position, target.position) <= 0.1f)
        {
            GetNextWaypoint();
        }
    }

    private void LateUpdate()
    {
        if (hp <= 0)
        {
            Die();
        }
    }

    public int getDamage()
    {
        return damage;
    }

    public int getHp()
    {
        return hp;
    }

    public void damageBalloon(int damage, bool canHitFrozen)
    {
        if (!frozen)
        {
            hp -= damage;
        }
        else if (frozen && canHitFrozen)
        {
            hp -= damage;
        }
    }

    void GetNextWaypoint()
    {
        if(wayPointIndex >= Waypoint.points.Length - 1)
        {
            Destroy(gameObject);

            WaveSpawner.BalloonsAlive--;
            GameObject.Find("GameController").GetComponent<WaveSpawner>().BalloonSurvived(damage);

            return;
        }
        wayPointIndex++;
        target = Waypoint.points[wayPointIndex];
    }

    public void freeze(float time)
    {
        frozen = true;
        lastspeed = speed;
        speed = 0;
        StopAllCoroutines();
        StartCoroutine(unfreezeTimer(time));
    }
    public void unfreeze()
    {
        frozen = false;
        speed = lastspeed;
    }

    private IEnumerator unfreezeTimer(float time)
    {
        float counter = time;
        while (counter > 0)
        {
            yield return new WaitForSeconds(.25f);
            counter -= .25f;
        }
        unfreeze();
    }

    void Die()
    {
        WaveSpawner.BalloonsAlive--;
        Destroy(gameObject);
        //give money based on the balloon that was popped  
        GameObject.Find("GameController").GetComponent<MoneyController>().balloonPopped(damage);
    }

    public void test()
    {
    }
}
