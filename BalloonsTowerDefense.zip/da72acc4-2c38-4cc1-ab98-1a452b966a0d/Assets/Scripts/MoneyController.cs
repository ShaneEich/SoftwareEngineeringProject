﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MoneyController : MonoBehaviour
{

    public int money;
    //private int red = 1;
    //private int blue = 2;
    //private int green = 3;
    //private int yellow = 4;
    //private int black = 9;
    //private int white = 9;
    
    public TextMeshProUGUI textbox;

    // Start is called before the first frame update
    void Start()
    {
        money = 650;
    }

    // Update is called once per frame
    void Update()
    {
        textbox.text = "Money: " + money;
    }

    public void soldTower(int towermoney)
    {
        money += towermoney;
    }

    public bool canBuyTower(int cost)
    {
        if(cost <= money)
        {
            //money -= cost;
            return true;
        }
        return false;
    }

    public bool buyTower(int cost)
    {
        if (cost <= money)
        {
            money -= cost;
            return true;
        }
        return false;
    }

    public bool buyUpgrade(int cost)
    {
        if (cost <= money)
        {
            money -= cost;
            return true;
        }
        return false;
    }

    public void balloonPopped(int rewardMoney)
    {
        money += rewardMoney;
        textbox.text = "Money: " + money;
    }

    public void roundEnded(int rewardMoney)
    {
        money += rewardMoney;
        textbox.text = "Money: " + money;
    }
}
