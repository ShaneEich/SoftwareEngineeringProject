﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class WaveSpawner : MonoBehaviour
{

    public static int BalloonsAlive = 0;
    //public Transform balloonPrefab;
    public Transform[] balloons;
    private Transform spawnPoint; //main spawn point - set this to current one
    public Transform spawnPoint1;
    public Transform spawnPoint2;

    public float timeBetweenWaves = 10f;
    public float countdown = 2f;

    public int waveNumber = 0;

    public TextMeshProUGUI waveText;

    public Button nextWaveButton;
    public HPController hpscript;
    public TextMeshProUGUI infoText;

    private bool wavestarted = false;
    private int roundover = 100;

    void Start()
    {
        Button btn = nextWaveButton.GetComponent<Button>();
        btn.onClick.AddListener(TaskOnClick);
        hpscript = GetComponent<HPController>();
        waveNumber = 0;
        BalloonsAlive = 0;

        if(spawnPoint2 == null)
        {
            spawnPoint2 = spawnPoint1;
        }
        spawnPoint = spawnPoint1;
    }
    

    public void TaskOnClick()
    {
        
        if (BalloonsAlive == 0)
        {            
            waveNumber++;
            spawnWaves();
            wavestarted = true;
        }
        waveText.text = "Wave: " + waveNumber.ToString();
    }

    void Update()
    {
        if(wavestarted && BalloonsAlive == 0)
        {
            gameObject.GetComponent<MoneyController>().roundEnded(roundover);
            roundover--;
            wavestarted = false;
        }
        if (waveNumber == 51 && wavestarted == false)
        {
            SceneManager.LoadScene("Credits");
        }
    }

    void nextWave()
    {
        spawnWaves();
    }

    void spawnWaves()
    {
        //Round 1: 12 Reds
        if (waveNumber == 1)
        {
            infoText.text = "Brace yourself. 12 red balloons are coming.";
            StartCoroutine(spawningReds(12));
        }
        //Round 2: 25 Reds
        else if (waveNumber == 2)
        {
            StartCoroutine(spawningReds(25));
            infoText.text = "More red balloons are coming. 25 to be exact.";
        }
        //Round 3: 24 Reds, 5 Blues
        else if (waveNumber == 3)
        {
            spawnPoint = spawnPoint2;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "Ready for the blue balloons? 24 reds, 5 blues.";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\nReady for the blue balloons? 24 reds, 5 blues.";
            }
            
            StartCoroutine(spawningReds(24));
            StartCoroutine(spawningBlues(5));
        }
        //Round 4: 10 Reds, 24 Blues
        else if (waveNumber == 4)
        {
            infoText.text = "More blues than reds. 10 reds and 24 blues. YAY!";
            StartCoroutine(spawningReds(10));
            StartCoroutine(spawningBlues(24));
        }
        // Round 5: 30 Reds, 25 Blues
        else if (waveNumber == 5)
        {
            infoText.text = "More reds than blues again? 30 reds and 25 blues.";
            StartCoroutine(spawningReds(30));
            StartCoroutine(spawningBlues(25));
        }
        // Round 6: 15 Green
        else if (waveNumber == 6)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "15 greens.";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n15 greens.";
            }
            StartCoroutine(spawningGreens(15));
        }
        // Round 7: 75 Blue
        else if (waveNumber == 7)
        {
            infoText.text = " 75 Blue.";
            StartCoroutine(spawningBlues(75));
        }
        //Round 8: 115 Reds, 68 Blues        
        else if (waveNumber == 8)
        {
            infoText.text = "Time for some fun. 115 reds and 68 blues!";
            StartCoroutine(spawningReds(115));
            StartCoroutine(spawningBlues(68));
        }
        //Round 9: 49 Blues, 22 Green        
        else if (waveNumber == 9)
        {
            infoText.text = "Time for some fun. 49 Blue, 22 Green!";
            StartCoroutine(spawningBlues(49));
            StartCoroutine(spawningGreens(22));
        }
        //Round 10: 40 Green
        else if (waveNumber == 10)
        {
            infoText.text = "More Green balloons are coming. 40 to be exact.";
            StartCoroutine(spawningGreens(40));
        }
        //Round 11: 24 Yellow
        else if (waveNumber == 11)
        {
            infoText.text = "24 Yellow";
            StartCoroutine(spawningYellows(24));
        }
        //Round 12: 30 Blue, 25 Green, 3 Yellow        
        else if (waveNumber == 12)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "30 Blue, 25 Green, 3 Yellow.";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n30 Blue, 25 Green, 3 Yellow.";
            }
            StartCoroutine(spawningYellows(3));
            StartCoroutine(spawningBlues(30));
            StartCoroutine(spawningGreens(25));
        }
        //Round 13: 40 Reds, 75 Blues, 30 Greens        
        else if (waveNumber == 13)
        {
            infoText.text = "Who let the greens out? 40 reds, 75 blues, 30 greens.";
             StartCoroutine(spawningReds(40));
            StartCoroutine(spawningBlues(75));
            StartCoroutine(spawningGreens(30));
           
        }
        //Round 14: 26 Yellows
        else if (waveNumber == 14)
        {
            infoText.text = "26 Yellows. Have fun!";
            StartCoroutine(spawningYellows(26));
        }
        //Round 15: 30 Blue, 60 Green
        else if (waveNumber == 15)
        {
            infoText.text = "30 Blue, 60 Green. Have fun!";
            StartCoroutine(spawningBlues(30));
            StartCoroutine(spawningGreens(60));
        }
        //Round 16: 80 Blue, 80 Green      
        else if (waveNumber == 16)
        {
            infoText.text = "80 Blue, 80 Green.";
            StartCoroutine(spawningBlues(80));
            StartCoroutine(spawningGreens(80));
        }
        //Round 17: 150 Blue, 30 Green      
        else if (waveNumber == 17)
        {
            infoText.text = "150 Blue, 30 Green.";
            StartCoroutine(spawningBlues(150));
            StartCoroutine(spawningGreens(30));
        }
        //Round 18: 30 Blue, 26 Green, 28 Yellow
        else if (waveNumber == 18)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "30 Blue, 26 Green, 28 Yellow.";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n30 Blue, 26 Green, 28 Yellow.";
            }
            StartCoroutine(spawningBlues(30));
            StartCoroutine(spawningGreens(26));
            StartCoroutine(spawningYellows(28));
        }
        //Round 19: 92 Green  
        else if (waveNumber == 19)
        {
            infoText.text = "92 Green.";
            StartCoroutine(spawningGreens(92));
        }
        //Round 20: 40 Blue, 60 Yellow
        if (waveNumber == 20)
        {
            infoText.text = "40 Blue, 60 Yellow.";
            StartCoroutine(spawningBlues(40));
            StartCoroutine(spawningGreens(60));
        }
        //Round 21: 10 Blue, 85 Green, 30 Yellow
        if (waveNumber == 21)
        {
            infoText.text = "10 Blue, 85 Green, 30 Yellow.";
            StartCoroutine(spawningBlues(10));
            StartCoroutine(spawningGreens(85));
            StartCoroutine(spawningYellows(30));
        }
        //Round 22: 45 Yellow
        if (waveNumber == 22)
        {
            infoText.text = "45 Yellow.";
            StartCoroutine(spawningYellows(45));
        }
        //Round 23: 64 Yellow, 35 Green        
        else if (waveNumber == 23)
        {
            infoText.text = "64 Yellow, 35 Green.";
            StartCoroutine(spawningGreens(35));
            StartCoroutine(spawningYellows(64));
        }
        //Round 24: 20 Blue, 60 Green, 30 Yellow
        if (waveNumber == 24)
        {
            infoText.text = "20 Blue, 60 Green, 30 Yellow.";
            StartCoroutine(spawningBlues(20));
            StartCoroutine(spawningGreens(60));
            StartCoroutine(spawningYellows(30));
        }
        //Round 25: 80 Green, 50 Yellow
        if (waveNumber == 25)
        {
            infoText.text = "80 Green, 50 Yellow.";
            StartCoroutine(spawningGreens(80));
            StartCoroutine(spawningYellows(50));
        }
        //Round 26: 85 Yellow       
        else if (waveNumber == 26)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "85 Yellow";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n85 Yellow";
            }
            StartCoroutine(spawningYellows(85));
        }
        //Round 27: 20 Black
        else if (waveNumber == 27)
        {
            infoText.text = "20 blacks. Have fun!";
            StartCoroutine(spawningBlacks(20));
        }
        //Round 28: 40 Green, 55 Yellow
        else if (waveNumber == 28)
        {
            infoText.text = "40 Green, 55 Yellow. Have fun!";
            StartCoroutine(spawningGreens(40));
            StartCoroutine(spawningYellows(55));
        }
        //Round 29: 125 Yellow, 20 Black
        else if (waveNumber == 29)
        {
            infoText.text = "125 Yellow, 20 Black. Have fun!";
            StartCoroutine(spawningYellows(125));
            StartCoroutine(spawningBlacks(20));
        }
        //Round 30: 252 Green
        else if (waveNumber == 30)
        {
            infoText.text = "252 Green. Have fun!";
            StartCoroutine(spawningGreens(252));
        }
        //Round 31: 10 Blue, 58 Green, 28 Black
        else if (waveNumber == 31)
        {
            infoText.text = "10 Blue, 58 Green, 28 Black. Have fun!";
            StartCoroutine(spawningBlues(10));
            StartCoroutine(spawningGreens(58));
            StartCoroutine(spawningBlacks(28));
        }
        //Round 32: 25 Green, 20 Yellow, 23 Black
        else if (waveNumber == 32)
        {
            infoText.text = "25 Green, 20 Yellow, 23 Black. Have fun!";
            StartCoroutine(spawningGreens(25));
            StartCoroutine(spawningYellows(20));
            StartCoroutine(spawningBlacks(23));
        }
        //Round 33: 150 Yellow
        else if (waveNumber == 33)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "150 Yellow. Have fun!";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n150 Yellow. Have fun!";
            }
            StartCoroutine(spawningYellows(150));
        }
        //Round 34: 35 Green, 35 Yellow, 25 Black
        else if (waveNumber == 34)
        {
            infoText.text = "35 Green, 35 Yellow, 25 Black. Have fun!";
            StartCoroutine(spawningGreens(35));
            StartCoroutine(spawningYellows(35));
            StartCoroutine(spawningBlacks(25));
        }
        //Round 35: 85 Green, 117 Yellow
        else if (waveNumber == 35)
        {
            infoText.text = "85 Green, 117 Yellow. Have fun!";
            StartCoroutine(spawningGreens(85));
            StartCoroutine(spawningYellows(117));
        }
        //Round 36: 118 Yellow, 33 Black
        else if (waveNumber == 36)
        {
            infoText.text = "118 Yellow, 33 Black. Have fun!";
            StartCoroutine(spawningYellows(118));
            StartCoroutine(spawningBlacks(33));
        }
        //Round 37: 59 Black
        else if (waveNumber == 37)
        {
            infoText.text = "59 Black. Have fun!";
            StartCoroutine(spawningBlacks(59));
        }
        //Round 38: 225 Yellow
        else if (waveNumber == 38)
        {
            infoText.text = "225 Yellow. Have fun!";
            StartCoroutine(spawningYellows(225));
        }
        //Round 39: 50 Reds, 50 Blues, 50 Greens, 50 Yellows, 40 Blacks
        else if (waveNumber == 39)
        {
            infoText.text = "50 reds, 50 blues, 50 greens, 50 yellows, 40 blacks. Have fun!";
            StartCoroutine(spawningReds(50));
            StartCoroutine(spawningBlues(50));
            StartCoroutine(spawningGreens(50));
            StartCoroutine(spawningYellows(50));
            StartCoroutine(spawningBlacks(40));
        }
        //Round 40: 80 Black
        else if (waveNumber == 40)
        {
            infoText.text = "80 Black. Have fun!";
            StartCoroutine(spawningBlacks(80));
        }
        //Round 41: 20 Black, 40 White
        else if (waveNumber == 41)
        {
            infoText.text = "20 Black, 40 White!";
            StartCoroutine(spawningBlacks(20));
            StartCoroutine(spawningWhites(40));
        }
        //Round 42: 50 Yellow, 30 Black, 30 White
        else if (waveNumber == 42)
        {
            infoText.text = "50 Yellow, 30 Black, 30 White!";
            StartCoroutine(spawningYellows(50));
            StartCoroutine(spawningBlacks(30));
            StartCoroutine(spawningWhites(30));
        }
        //Round 43: 152 Yellow, 48 Black, 40 White
        else if (waveNumber == 43)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "152 Yellow, 48 Black, 40 White!";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n152 Yellow, 48 Black, 40 White!";
            }
            StartCoroutine(spawningYellows(152));
            StartCoroutine(spawningBlacks(48));
            StartCoroutine(spawningWhites(40));
        }
        //Round 44: 120 Black
        else if (waveNumber == 44)
        {
            infoText.text = "120 Black. Have fun!";
            StartCoroutine(spawningBlacks(120));
        }
        //Round 45: 125 White
        else if (waveNumber == 45)
        {
            infoText.text = "125 White!";
            StartCoroutine(spawningWhites(125));
        }
        //Round 46: 60 Yellow, 60 Black, 60 White
        else if (waveNumber == 46)
        {
            infoText.text = "60 Yellow, 60 Black, 60 White!";
            StartCoroutine(spawningYellows(60));
            StartCoroutine(spawningBlacks(60));
            StartCoroutine(spawningWhites(60));
        }
        //Round 47: 80 Yellow, 70 Black, 40 White
        else if (waveNumber == 47)
        {
            infoText.text = "80 Yellow, 70 Black, 40 White!";
            StartCoroutine(spawningYellows(80));
            StartCoroutine(spawningBlacks(70));
            StartCoroutine(spawningWhites(40));
        }
        //Round 48: 70 Yellow, 76 Black, 76 White
        else if (waveNumber == 48)
        {
            infoText.text = "76 Yellow, 76 Black, 76 White!";
            StartCoroutine(spawningYellows(76));
            StartCoroutine(spawningBlacks(76));
            StartCoroutine(spawningWhites(76));
        }
        //Round 49: 100 Yellow, 83 Black, 70 White
        else if (waveNumber == 49)
        {
            spawnPoint = spawnPoint1;
            Waypoint.swapSpawn();
            if (spawnPoint2 == spawnPoint1)
            {
                infoText.text = "100 Yellow, 83 Black, 70 White!";
            }
            else
            {
                infoText.text = "Watch out! They changed lanes!\n100 Yellow, 83 Black, 70 White!";
            }
            StartCoroutine(spawningYellows(100));
            StartCoroutine(spawningBlacks(83));
            StartCoroutine(spawningWhites(70));
        }
        //Round 50: 100 Black, 100 White
        else if (waveNumber == 50)
        {
            infoText.text = "100 Black, 100 White. Final Round!";
            StartCoroutine(spawningBlacks(100));
            StartCoroutine(spawningWhites(100));
        }
        Debug.Log("Wave Spawning.");
    }

    IEnumerator spawningReds(int amount)
    {
        for (int j = 0; j < amount; j++)
        {
            SpawnRed();
            yield return new WaitForSeconds(Random.Range(0.1f, 0.4f));
        }
    }
    IEnumerator spawningBlues(int amount)
    {
        for (int j = 0; j < amount; j++)
        {
            SpawnBlue();
            yield return new WaitForSeconds(Random.Range(0.1f, 0.4f));
        }
    }
    IEnumerator spawningGreens(int amount)
    {
        for (int j = 0; j < amount; j++)
        {
            SpawnGreen();
            yield return new WaitForSeconds(Random.Range(0.1f, 0.4f));
        }
    }
    IEnumerator spawningYellows(int amount)
    {
        for (int j = 0; j < amount; j++)
        {
            SpawnYellow();
            yield return new WaitForSeconds(Random.Range(0.1f, 0.4f));
        }
    }
    IEnumerator spawningBlacks(int amount)
    {
        for (int j = 0; j < amount; j++)
        {
            SpawnBlack();
            yield return new WaitForSeconds(Random.Range(0.1f, 0.4f));
        }
    }
    IEnumerator spawningWhites(int amount)
    {
        for (int j = 0; j < amount; j++)
        {
            SpawnWhite();
            yield return new WaitForSeconds(Random.Range(0.1f, 0.4f));
        }
    }

    void SpawnRed()
    {
        GameObject balloon = Instantiate(balloons[0], spawnPoint.transform).gameObject;
        balloon.transform.position = spawnPoint.transform.position;
        BalloonsAlive++;
        
    }

    void SpawnBlue()
    {
        GameObject balloon = Instantiate(balloons[1], spawnPoint.transform).gameObject;
        balloon.transform.position = spawnPoint.transform.position;
        BalloonsAlive++;
    }

    void SpawnGreen()
    {

        GameObject balloon = Instantiate(balloons[2], spawnPoint.transform).gameObject;
        balloon.transform.position = spawnPoint.transform.position;
        BalloonsAlive++;
         
    }

    void SpawnYellow()
    {

        GameObject balloon = Instantiate(balloons[3], spawnPoint.transform).gameObject;
        balloon.transform.position = spawnPoint.transform.position;
        BalloonsAlive++;
         
    }

    void SpawnBlack()
    {

        GameObject balloon = Instantiate(balloons[4], spawnPoint.transform).gameObject;
        balloon.transform.position = spawnPoint.transform.position;
        BalloonsAlive++;

    }

    void SpawnWhite()
    {

        GameObject balloon = Instantiate(balloons[5], spawnPoint.transform).gameObject;
        balloon.transform.position = spawnPoint.transform.position;
        BalloonsAlive++;
         
    }

    
    public void BalloonSurvived(int damage)
    {
        hpscript.balloonPast(damage);
    }
}
