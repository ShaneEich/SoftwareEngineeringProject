﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelSelections : MonoBehaviour
{
    public Image level1Image;
    public Button level1Button;
    public Image level2Image;
    public Button level2Button;
    public Image level3Image;
    public Button level3Button;
    public Image level4Image;
    public Button level4Button;
    public Image level5Image;
    public Button level5Button;

    public int cycle = 1;

    private void Start()
    {
        level1Image.gameObject.SetActive(true);
        level1Button.gameObject.SetActive(true);
        level2Image.gameObject.SetActive(true);
        level2Button.gameObject.SetActive(true);
        level3Image.gameObject.SetActive(false);
        level3Button.gameObject.SetActive(false);
        level4Image.gameObject.SetActive(false);
        level4Button.gameObject.SetActive(false);
        level5Image.gameObject.SetActive(false);
        level5Button.gameObject.SetActive(false);
    }

    public void invoke()
    {
        if (cycle == 1)
        {
            level1Image.gameObject.SetActive(false);
            level1Button.gameObject.SetActive(false);
            level2Image.gameObject.SetActive(false);
            level2Button.gameObject.SetActive(false);
            level3Image.gameObject.SetActive(true);
            level3Button.gameObject.SetActive(true);
            level4Image.gameObject.SetActive(true);
            level4Button.gameObject.SetActive(true);
            level5Image.gameObject.SetActive(false);
            level5Button.gameObject.SetActive(false);
            cycle = 2;
        }
        else if (cycle == 2)
        {
            level1Image.gameObject.SetActive(false);
            level1Button.gameObject.SetActive(false);
            level2Image.gameObject.SetActive(false);
            level2Button.gameObject.SetActive(false);
            level3Image.gameObject.SetActive(false);
            level3Button.gameObject.SetActive(false);
            level4Image.gameObject.SetActive(false);
            level4Button.gameObject.SetActive(false);
            level5Image.gameObject.SetActive(true);
            level5Button.gameObject.SetActive(true);
            cycle = 3;
        }
        else if (cycle == 3)
        {
            level1Image.gameObject.SetActive(true);
            level1Button.gameObject.SetActive(true);
            level2Image.gameObject.SetActive(true);
            level2Button.gameObject.SetActive(true);
            level3Image.gameObject.SetActive(false);
            level3Button.gameObject.SetActive(false);
            level4Image.gameObject.SetActive(false);
            level4Button.gameObject.SetActive(false);
            level5Image.gameObject.SetActive(false);
            level5Button.gameObject.SetActive(false);
            cycle = 1;
        }
    }
}
