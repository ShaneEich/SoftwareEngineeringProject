﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class HPController : MonoBehaviour
{
    public TextMeshProUGUI hptext;
    [SerializeField]
    private int hp = 100;

    // Start is called before the first frame update
    void Start()
    {
        hptext.text = "Lives: " + hp;
    }

    // Update is called once per frame
    void Update()
    {
        hptext.text = "Lives: " + hp;
    }

    public void balloonPast(int damage)
    {
        //damage = bc.damage;
        hp = hp - damage;
        //bc.test();

        //game ends; send scene to game over
        if (hp <= 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
}
