﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TileInteract : MonoBehaviour {

    public Grid grid;
    public GameObject TowerObject;
    public GameObject SelectedTower;

    public GameObject validholder;
    
    
    public List<GameObject> validtiles;
    [SerializeField]
    public List<GameObject> usedtiles;

    public GameObject TileHighlightGreen;
    public GameObject TileHighlightRed;

    private Vector3 gridPlacement;
    private Vector3 mouseWorldPos;
    private Vector3Int cellPosition;

    public Button sellButton;
    public Button upgradeButton;

    public TextMeshProUGUI towertext;
    private MoneyController MoneyController;

    [SerializeField]
    private Transform DartMonkey;
    [SerializeField]
    private Transform TackShooter;
    [SerializeField]
    private Transform BombTower;
    [SerializeField]
    private Transform SuperMonkey;
    [SerializeField]
    private Transform IceMonkey;

    private GameObject TowerObjectHighlight;
    private string towername;


    private void Start()
    {
        validtiles = new List<GameObject>();
        usedtiles = new List<GameObject>();
        if (validholder != null)
        {
            
            foreach (Transform tile in validholder.transform)
            {
                validtiles.Add(tile.gameObject);
            }
        }
        sellButton.gameObject.SetActive(false);
        upgradeButton.gameObject.SetActive(false);
        MoneyController = GameObject.Find("GameController").GetComponent<MoneyController>();
        
    }

    public void ChangeTower(GameObject tower)
    {
        TowerObject = tower;
    }

    public void ChangeName(string name)
    {
        towername = name;
    }

    private GameObject previousHighlight;

    public void Update()
    {
        //this block runs if the player is trying to place a tower
        if (TowerObject != null)
        {
            if(SelectedTower!= null)
            {
                TowerController controller = SelectedTower.GetComponent<TowerController>();
                controller.destroyCircle();
                upgradeButton.gameObject.SetActive(false);
                sellButton.gameObject.SetActive(false);
            }
            SelectedTower = null;
            if (MoneyController.canBuyTower((int)TowerObject.GetComponent<TowerController>().towerPrice))
            {
                towertext.text = TowerObject.GetComponent<TowerController>().getInfoText();
            }
            else
            {
                towertext.text = "You don't have enough money!\nTower Price: "+ (int)TowerObject.GetComponent<TowerController>().towerPrice;
            }
            mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            cellPosition = grid.WorldToCell(mouseWorldPos);
            gridPlacement = grid.GetCellCenterWorld(cellPosition);

            foreach (GameObject loc in validtiles)
            {
                if (loc.transform.position.x == gridPlacement.x && loc.transform.position.y == gridPlacement.y)
                {
                    if (MoneyController.canBuyTower((int)TowerObject.GetComponent<TowerController>().towerPrice))
                    {
                        if (previousHighlight != null)
                        {
                            Destroy(previousHighlight);
                            previousHighlight = null;
                        }
                        previousHighlight = Instantiate(TileHighlightGreen);
                        previousHighlight.transform.position = loc.transform.position;
                    }
                    else
                    {
                        if (previousHighlight != null)
                        {
                            Destroy(previousHighlight);
                            previousHighlight = null;
                        }
                        previousHighlight = Instantiate(TileHighlightRed);
                        previousHighlight.transform.position = loc.transform.position;
                    }

                }
            }
            foreach (GameObject loc in usedtiles)
            {
                if (loc.transform.position.x == gridPlacement.x && loc.transform.position.y == gridPlacement.y)
                {
                    if (previousHighlight != null)
                    {
                        Destroy(previousHighlight);
                        previousHighlight = null;
                    }
                    previousHighlight = Instantiate(TileHighlightRed);
                    previousHighlight.transform.position = loc.transform.position;
                }
            }
            if (Input.GetMouseButtonDown(0))
            {
                if (MoneyController.canBuyTower((int)TowerObject.GetComponent<TowerController>().towerPrice))
                {
                    PlaceObject();
                    towertext.text = "Click a tower or the buttons on the right for more info! Right-Click to cancel selection.";
                }
                else
                {
                    towertext.text = "Click a tower or the buttons on the right for more info! Right-Click to cancel selection.";
                    TowerObject = null;
                    Destroy(previousHighlight);
                    previousHighlight = null;
                }
            }
            else if (Input.GetMouseButtonDown(1))
            {
                towertext.text = "";
                TowerObject = null;
                Destroy(previousHighlight);
                previousHighlight = null;
            }

        }

        //this block runs when not trying to place a tower and a tower isnt chosen
        else if (SelectedTower == null && TowerObject == null) //tower isnt selected and button not pressed / so the user wants to click a tower or a button
        {
            SelectedTower = null;
            mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            cellPosition = grid.WorldToCell(mouseWorldPos);
            gridPlacement = grid.GetCellCenterWorld(cellPosition);

            Vector2 check = new Vector2(gridPlacement.x, gridPlacement.y);
            GameObject tower = null;
            foreach (Transform loc in this.transform)
            {
                if (loc.transform.position.x == check.x && loc.transform.position.y == check.y)
                {
                    if (loc.gameObject.tag.Equals("Tower"))
                    {
                        tower = loc.gameObject;
                        break;
                    }
                }
            }
            if (Input.GetMouseButtonDown(0)) //if they click on tower, it is selected
            {
                if (tower != null)
                {
                    SelectedTower = tower;
                    towertext.text = SelectedTower.GetComponent<TowerController>().getTowerText();
                    sellButton.gameObject.SetActive(true);
                    if (SelectedTower.GetComponent<TowerController>().upgradeTower() != 0)
                    {
                        upgradeButton.gameObject.SetActive(true);
                    }
                }
            }
        }


        //this runs if tower is selected 
        else if (SelectedTower != null)
        {
            TowerController controller = SelectedTower.GetComponent<TowerController>();
            towertext.text = controller.getTowerText();
            controller.DrawCircle();
            if (Input.GetMouseButtonDown(1)) //user right clicks to remove selection
            {
                towertext.text = "Click a tower or the buttons on the right for more info! Right-Click to cancel selection.";
                controller.destroyCircle();
                SelectedTower = null;
                TowerObject = null;

                sellButton.gameObject.SetActive(false);
                upgradeButton.gameObject.SetActive(false);
            }
            else if (Input.GetMouseButtonDown(0)) //user left clicks while a tower is selected
            {
                mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                cellPosition = grid.WorldToCell(mouseWorldPos);
                gridPlacement = grid.GetCellCenterWorld(cellPosition);

                Vector2 check = new Vector2(gridPlacement.x, gridPlacement.y);
                GameObject tower = null;
                foreach (Transform loc in this.transform) //check if mouse is on a tower
                {
                    if (loc.transform.position.x == check.x && loc.transform.position.y == check.y)
                    {
                        if (loc.gameObject.tag.Equals("Tower"))
                        {
                            tower = loc.gameObject;
                            break;
                        }
                    }
                }
                if (tower != null) //tower isnt null so we change selection to new tower
                {
                    controller.destroyCircle();
                    SelectedTower = tower;
                    sellButton.gameObject.SetActive(true);
                    if (SelectedTower.GetComponent<TowerController>().upgradeTower() != 0)
                    {
                        upgradeButton.gameObject.SetActive(true);
                    }
                }
                else
                {
                    
                    bool ingrid = false;
                    BoxCollider2D gridCollider = GameObject.Find("TilemapGrid").GetComponent<BoxCollider2D>();
                    if (gridCollider.bounds.Contains(check))
                    {
                        ingrid = true;
                    }

                    if (ingrid)
                    {
                        towertext.text = "Click a tower or the buttons on the right for more info! Right-Click to cancel selection.";
                        controller.destroyCircle();
                        SelectedTower = null;
                        TowerObject = null;

                        sellButton.gameObject.SetActive(false);
                        upgradeButton.gameObject.SetActive(false);
                    }
                }
                /*
                else //tower is null so we get rid of selection
                {
                    towertext.text = "Click a tower or the buttons on the right for more info! Right-Click to cancel selection.";
                    controller.destroyCircle();
                    SelectedTower = null;
                    TowerObject = null;

                    sellButton.gameObject.SetActive(false);
                    upgradeButton.gameObject.SetActive(false);
                }
                */
            }
        }
        if(TowerObject != null && towername != null && TowerObjectHighlight == null)
        {
            TowerObjectHighlight = Instantiate(TileHighlightGreen);
            if(towername == "DartMonkey") { TowerObjectHighlight.transform.position = DartMonkey.transform.position; }
            else if (towername == "SuperMonkey") { TowerObjectHighlight.transform.position = SuperMonkey.transform.position; }
            else if (towername == "TackShooter") { TowerObjectHighlight.transform.position = TackShooter.transform.position; }
            else if (towername == "BombTower") { TowerObjectHighlight.transform.position = BombTower.transform.position; }
            else if (towername == "IceMonkey") { TowerObjectHighlight.transform.position = IceMonkey.transform.position; }
        }
        else if (TowerObject == null && TowerObjectHighlight != null)
        {
            Destroy(TowerObjectHighlight.gameObject);
            TowerObjectHighlight = null;
            towername = null;
        }
    }
    

    public void sellTower()
    {
        if (SelectedTower != null && sellButton.enabled)
        {
            //int money = SelectdTower.GetComponent<TowerInfo>().sellcost;
            foreach (GameObject loc in usedtiles)
            {
                if (loc.transform.position.x == SelectedTower.transform.position.x
                    && loc.transform.position.y == SelectedTower.transform.position.y)
                {
                    usedtiles.Remove(loc);
                    validtiles.Add(loc);
                    break;
                }
            }
            GameObject.Find("GameController").GetComponent<MoneyController>().soldTower((int)SelectedTower.GetComponent<TowerController>().getTowerValue());
            Destroy(SelectedTower);
            SelectedTower = null;
            sellButton.gameObject.SetActive(false);
            upgradeButton.gameObject.SetActive(false);
            //return money;
        }
    }

    public void upgradeTower()
    {
        if(SelectedTower != null && upgradeButton.enabled)
        {
            if (GameObject.Find("GameController").GetComponent<MoneyController>().buyUpgrade(((int)SelectedTower.GetComponent<TowerController>().upgradeTower())))
            {
                SelectedTower.GetComponent<TowerController>().buyUpgrade();
                if (SelectedTower.GetComponent<TowerController>().upgradeTower() == 0)
                {
                    upgradeButton.gameObject.SetActive(false);
                }
            }
        }
    }

    private bool PlaceObject()
    {
        bool placementGood = false;
        Vector2 check = new Vector2(gridPlacement.x, gridPlacement.y);
        foreach (GameObject loc in validtiles)
        {
            if (loc.transform.position.x == check.x && loc.transform.position.y == check.y)
            {
                placementGood = true;
                validtiles.Remove(loc);
                usedtiles.Add(loc);
                break;
            }
        }
        if (placementGood)
        {
            GameObject tower = Instantiate(TowerObject, transform);
            tower.transform.position = new Vector3(check.x, check.y, 0);
            MoneyController.buyTower((int)TowerObject.GetComponent<TowerController>().towerPrice);
            TowerObject = null;
            Destroy(previousHighlight);
            previousHighlight = null;
            return true;
        }
        return false;
    }

}


/*
Create an array of empty gameobjects each of which should be positioned at the centre of each grid square. (Hence forth referred to as centreObjects).

Cast a ray from the mouse position to the ground, and store the hit location in a variable.

Compare the distance between the hit location and all of the centreObjects and find out which centreObject has the smallest distance to the hit location (distance can be found through Vector3 magnitude).

In advance, prepare a prefab with 4 particle systems that mimics the edges of a grid square.

Instantiate the prefab at the closest centreObject.

(Check each frame if the centreObject has changed, and if so, destroy the previous prefab, and instantiate a new one).

*/
