﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerController : MonoBehaviour
{
    private GameObject TowerObject;
    private double towerValue;
    public double towerPrice, upgrade1Price, upgrade2Price;
    [SerializeField]
    private bool upgradedTower = false;
    [SerializeField]
    private bool fullyUpgraded = false;

    //Attacking Stats
    public float attackRange;
    public float attackCooldown;
    private float nextAttack;
    public int attackDamage;
    private Transform target;
    private BalloonController targetEnemy;

    //specific tower attacking stats
    private float explosionSize = .75f;
    private float freezetime = .75f;

    //text stats
    [SerializeField]
    [TextArea]
    private string TowerInfoText = "";
    [SerializeField]
    [TextArea]
    private string Upgrade1Text = "";
    [SerializeField]
    [TextArea]
    private string Upgrade2Text = "";
    [SerializeField]
    [TextArea]
    private string FullyUpgradedText = "";

    public CircleCollider2D attackTrigger;
    public GameObject dart;

    // Start is called before the first frame update
    void Start()
    {
        //Gizmos.DrawSphere(this.transform.position, attackRange);
        TowerObject = this.gameObject;
        towerValue = getTowerValue();
        nextAttack = attackCooldown;
        //moneycontroller = GameObject.Find("GameController").GetComponent<MoneyController>();

        attackTrigger.radius = attackRange;
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Balloon")
        {
            GameObject enemy = collision.gameObject;
            target = enemy.transform;
            targetEnemy = enemy.GetComponent<BalloonController>();
            if (Time.time > nextAttack && targetEnemy != null)
            {
                nextAttack = Time.time + attackCooldown;
                if (gameObject.name == "Bomb Tower(Clone)") { bombattack(); }
                else if (gameObject.name == "Dart Monkey(Clone)") { dartattack(); }
                else if (gameObject.name == "Ice Monkey(Clone)") { iceattack(); }
                else if (gameObject.name == "Super Monkey(Clone)") { superattack(); }
                else if (gameObject.name == "Tack Shooter(Clone)") { tackattack(); }
            }
            target = null;
            targetEnemy = null;
        }
        /*
        if (collision.gameObject.tag == "Balloon")
        {
            GameObject[] enemies = GameObject.FindGameObjectsWithTag("Balloon");
            float shortestDistance = Mathf.Infinity;
            GameObject nearestEnemy = null;
            int count = 0;
            foreach (GameObject enemy in enemies)
            {
                float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
                // Debug.Log(count);
                // Debug.Log(distanceToEnemy);
                count++;
                if (distanceToEnemy < shortestDistance)
                {
                    shortestDistance = distanceToEnemy;
                    nearestEnemy = enemy;
                }
            }

            if (nearestEnemy != null && shortestDistance <= attackRange)
            {
                target = nearestEnemy.transform;
                targetEnemy = nearestEnemy.GetComponent<BalloonController>();
            }
            else
            {
                target = null;
            }

            if (Time.time > nextAttack && targetEnemy != null)
            {
                nextAttack = Time.time + attackCooldown;
                if (gameObject.name == "Bomb Tower(Clone)") { bombattack(); }
                else if (gameObject.name == "Dart Monkey(Clone)") { dartattack(); }
                else if (gameObject.name == "Ice Monkey(Clone)") { iceattack(); }
                else if (gameObject.name == "Super Monkey(Clone)") { superattack(); }
                else if (gameObject.name == "Tack Shooter(Clone)") { tackattack(); }
            }
            target = null;
            targetEnemy = null;
        }
        */
    }

    public void bombattack()//bomb tower attack method
    {
        //raycast attacks with explosions
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Balloon");
        foreach (GameObject enemy in enemies)
        {
            float distanceToEnemy = Vector3.Distance(targetEnemy.transform.position, enemy.transform.position);
            if (distanceToEnemy < explosionSize)
            {
                enemy.GetComponent<BalloonController>().damageBalloon(attackDamage, true);
            }
        }
        transform.up = targetEnemy.transform.position - transform.position;
        targetEnemy.damageBalloon(attackDamage, true);

    }

    public void dartattack()//dart tower attack method
    {
        GameObject newdart = Instantiate(dart, transform);
        DartMovement move = newdart.GetComponent<DartMovement>();
        move.tower = this;
        move.bal = targetEnemy;

        transform.up = targetEnemy.transform.position - transform.position;
    }

    public void iceattack()//ice tower attack method
    {
        //aoe attacks at tower that stop/slow
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Balloon");
        foreach (GameObject enemy in enemies)
        {
            float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
            if (distanceToEnemy < attackRange)
            {
                enemy.GetComponent<BalloonController>().freeze(freezetime);
            }
        }
    }

    public void superattack()//super tower attack method
    {
        GameObject newdart = Instantiate(dart, transform);
        DartMovement move = newdart.GetComponent<DartMovement>();
        move.tower = this;
        move.bal = targetEnemy;


        transform.up = targetEnemy.transform.position - transform.position;
    }

    public void tackattack()//tack tower attack method
    {//tack tower attacking is designed around the tower only shooting one dart in 8 total directions. angle gets angle between the balloon and tower and next linechecks for left/right side
        bool hit1 = false;
        bool hit2 = false;
        bool hit3 = false;
        bool hit4 = false;
        bool hit5 = false;
        bool hit6 = false;
        bool hit7 = false;
        bool hit8 = false;
        //aoe attacks at tower
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Balloon");
        foreach (GameObject enemy in enemies)
        {
            float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
            if (distanceToEnemy < attackRange)
            {
                Vector3 dir = enemy.transform.position - transform.position;
                Vector3 forward = transform.up;
                float angle = Vector3.Angle(dir, forward);
                bool right;
                if (Vector3.Angle(target.right, dir) > 90f) right = false; else right = true;
                if (angle < 45.0f && angle > 0 && !hit1 && !right)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit1 = true;
                }
                if (angle < 90.0f && angle > 45.0f && !hit2 && !right)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit2 = true;
                }
                if (angle < 135.0f && angle > 90.0f && !hit3 && !right)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit3 = true;
                }
                if (angle < 180.0f && angle > 135.0f && !hit4 && !right)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit4 = true;
                }
                if (angle < 45.0f && angle > 0 && right == true && !hit5)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit5 = true;
                }
                if (angle < 90.0f && angle > 45.0f && right == true && !hit6)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit6 = true;
                }
                if (angle < 135.0f && angle > 90.0f && right == true && !hit7)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit7 = true;
                }
                if (angle < 180.0f && angle > 135.0f && right == true && !hit8)
                {
                    GameObject newdart = Instantiate(dart, transform);
                    DartMovement move = newdart.GetComponent<DartMovement>();
                    move.tower = this;
                    move.bal = enemy.GetComponent<BalloonController>();

                    hit8 = true;
                }
            }
        }
    }

    public string getInfoText()
    {
        return TowerInfoText + ((int)getTowerValue()).ToString();
    }

    public string getTowerText()
    {
        if (!upgradedTower)
        {
            return Upgrade1Text + ((int)getTowerValue()).ToString();
        }
        else if (upgradedTower && !fullyUpgraded)
        {
            return Upgrade2Text + ((int)getTowerValue()).ToString();
        }
        else
        {
            return FullyUpgradedText + ((int)getTowerValue()).ToString();
        }
    }

    //checks the value of a tower with or without upgrades 
    public double getTowerValue()
    {
        //if the tower is not upgraded,this runs
        if (!upgradedTower)
        {
            towerValue = (towerPrice * 0.8);
        }
        //if the tower is upgraded,this runs
        else if (upgradedTower)
        {
            //if the tower is not fully upgraded,this runs
            if (!fullyUpgraded)
            {
                towerValue = (towerPrice + upgrade1Price) * 0.8;
            }
            //if the tower is fully upgraded,this runs
            else if (fullyUpgraded)
            {
                towerValue = (towerPrice + upgrade1Price + upgrade2Price) * .8;
            }
        }
        return towerValue;
    }

    //etermines price of the upgrade
    public double upgradeTower()
    {
        if (!upgradedTower)
        {
            return upgrade1Price;
        }

        else if (upgradedTower)
        {
            if (!fullyUpgraded)
            {
                return upgrade2Price;
            }

            else if (!fullyUpgraded)
            {
                Debug.Log("No more upgrades are available for this tower.");
            }
        }
        return 0;
    }

    //performs the tower upgrade
    public void buyUpgrade()
    {
        if (!upgradedTower)
        {
            upgradedTower = true;
            if (gameObject.name == "Bomb Tower(Clone)") { explosionSize += .5f; }
            else if (gameObject.name == "Dart Monkey(Clone)") { attackDamage += 1; attackTrigger.radius = attackRange; }
            else if (gameObject.name == "Ice Monkey(Clone)") { freezetime += .5f; }
            else if (gameObject.name == "Super Monkey(Clone)") { attackRange += 1.5f; attackTrigger.radius = attackRange; fullyUpgraded = true; }
            else if (gameObject.name == "Tack Shooter(Clone)") { attackCooldown -= .4f; }
        }
        else if (upgradedTower)
        {
            if (!fullyUpgraded)
            {
                fullyUpgraded = true;
                if (gameObject.name == "Bomb Tower(Clone)") { attackRange += 1f; attackTrigger.radius = attackRange; }
                else if (gameObject.name == "Dart Monkey(Clone)") { attackRange += .75f; attackTrigger.radius = attackRange; }
                else if (gameObject.name == "Ice Monkey(Clone)") { attackRange += .75f; attackTrigger.radius = attackRange; }
                else if (gameObject.name == "Super Monkey(Clone)") { Debug.Log("You shouldn't be here."); }
                else if (gameObject.name == "Tack Shooter(Clone)") { attackRange += .75f; attackTrigger.radius = attackRange; }
            }

            else if (!fullyUpgraded)
            {
                Debug.Log("No more upgrades are available for this tower.");
            }
        }
        destroyCircle();
        DrawCircle();
    }

    public void DrawCircle()
    {
        if (gameObject.GetComponent<LineRenderer>() == null)
        {
            var segments = 360;
            var line = gameObject.AddComponent<LineRenderer>();
            line.useWorldSpace = false;
            line.startWidth = .02f;
            line.endWidth = .02f;
            line.positionCount = segments + 1;

            var pointCount = segments + 1; // add extra point to make startpoint and endpoint the same to close the circle
            var points = new Vector3[pointCount];

            for (int i = 0; i < pointCount; i++)
            {
                var rad = Mathf.Deg2Rad * (i * 360f / segments);
                points[i] = new Vector3(Mathf.Sin(rad) * attackRange, Mathf.Cos(rad) * attackRange, -3);
            }

            line.SetPositions(points);
        }
    }

    public void destroyCircle()
    {
        Destroy(gameObject.GetComponent<LineRenderer>());
    }


}
