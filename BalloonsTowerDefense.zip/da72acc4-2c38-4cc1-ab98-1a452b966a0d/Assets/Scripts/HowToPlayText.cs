﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class HowToPlayText : MonoBehaviour
{
    public TextMeshProUGUI text;

    public void basic()
    {
        text.text = "The basics of the game is to survive! Buy towers in order to fortify your defenses to defend against the balloons! When you are ready for the waves click the Next Wave button. If you want to quit the game click the End Game button. You get money from each balloon you pop and each round you survive. Use the money to buy more and upgrade existing ones.";
    }

    public void buying()
    {
        text.text = "In order to buy towers, left-click the buttons on the right and then left-click on a valid tile in the game space. You can tell it is valid by the green square when hovering a tile (Red if invalid)! The descriptions tell you how much money you need to purchase so make sure you have enough!";
    }

    public void upgrading()
    {
        text.text = "In order to upgrade towers, left-click the tower you want to upgrade and left-click the upgrade button on the right side! Read what the upgrades do and how much they cost in the text presented in the descriptions of the tower! You can also sell the towers using the same methods as upgrading!";
    }
}