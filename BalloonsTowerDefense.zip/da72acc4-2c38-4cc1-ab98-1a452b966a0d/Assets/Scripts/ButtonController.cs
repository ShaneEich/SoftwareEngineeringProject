﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum buttons { MENU, LEVELSELECT, QUIT, HOWTOPLAY, LEVEL1, LEVEL2, LEVEL3, LEVEL4, LEVEL5, CREDITS};

public class ButtonController : MonoBehaviour {

    public buttons Button;
    

    public void InvokeClick()
    {
        if(Button == buttons.MENU)
        {
            SceneManager.LoadScene("MainMenu");
        }
        else if (Button == buttons.LEVELSELECT)
        {
            SceneManager.LoadScene("LevelSelect");
        }
        else if (Button == buttons.QUIT)
        {
            Application.Quit();
        }
        else if (Button == buttons.HOWTOPLAY)
        {
            SceneManager.LoadScene("HowToPlay");
        }
        else if (Button == buttons.LEVEL1)
        {
            SceneManager.LoadScene("Level1");
        }
        else if (Button == buttons.LEVEL2)
        {
            SceneManager.LoadScene("Level2");
        }
        else if (Button == buttons.LEVEL3)
        {
            SceneManager.LoadScene("Level3");
        }
        else if (Button == buttons.LEVEL4)
        {
            SceneManager.LoadScene("Level4");
        }
        else if (Button == buttons.LEVEL5)
        {
            SceneManager.LoadScene("Level5");
        }
        else if (Button == buttons.CREDITS)
        {
            SceneManager.LoadScene("Credits");
        }
    }
}
