﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoint : MonoBehaviour
{
    public static Transform[] points;
    public static Transform[] points1;
    public static Transform[] points2;
    public GameObject p1;
    public GameObject p2;

    void Awake()
    {
        points1 = new Transform[p1.transform.childCount];
        for (int i = 0; i < points1.Length; i++)
        {
            points1[i] = p1.transform.GetChild(i);
        }
        if(p2 != null)
        {
            points2 = new Transform[p2.transform.childCount];
            for (int i = 0; i < points2.Length; i++)
            {
                points2[i] = p2.transform.GetChild(i);
            }
        }
        else
        {
            points2 = points1;
        }
        points = points1;
    }

    public static void swapSpawn()
    {
        if(points == points1)
        {
            points = points2;
        }
        else
        {
            points = points1;
        }
    }


}
